<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>Designed by</b>
      </div>
      <strong>Tayaba Amin Medha &copy; 2022 <a href="https://www.facebook.com/Tayaba Amin Medha">BRAC UNIVERSITY</a></strong>
    </div>
</footer>