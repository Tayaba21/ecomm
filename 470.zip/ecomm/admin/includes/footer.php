<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Designed By</b>
    </div>
     <strong>Tayaba AMIN &copy; 2022 <a href="https://www.facebook.com/TayabaAMIN">BRAC UNIVERSITY</a></strong>
</footer>